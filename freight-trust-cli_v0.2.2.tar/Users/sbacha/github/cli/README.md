# @freight-trust/cli


curl -L cli.freight.sh | sh

## Overview 

ftcli --help

## License

MIT
